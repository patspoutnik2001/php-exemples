<!DOCTYPE html>
<html>
	<head>
		<title>Exercice sur inversion chaine</title>
		<meta charset="UTF-8" />
		<meta name="author" content="votre nom" />
	</head>
	<body>
	
<?php

/*********************************************************************************
inversion chaine
*********************************************************************************/
$sChaine = 'coucouIG'; // derrière cette chaine se cache un Tableau de caractères
// c o u c o u I G
// 0 1 2 3 4 5 6 7
// pour accéder à  l'élément 2 du tableau : $sChaine[2] => 'u'
// strlen (string - length)  =longueur de la chaine de caractères
// dans le cas de "coucouIG" la longueur = 8
$sInverse='';
// on parcourt le tableau en commencant par la dernière cellule
$iLongueur = strlen($sChaine);
for($i = $iLongueur-1 ; $i>=0 ; $i--)	//$iLongueur-1 car on va de 0 à 7 et pas de 0 à 8
{
	$sInverse.=$sChaine[$i];
}
echo $sChaine.' => '.$sInverse;

/***********************************************************************************
// autre possibilité
moins performante car nécessite un calcul supplémentaire
***********************************************************************************/
$sChaine = 'coucouIG';
$sInverse = '';
$iLongueur = strlen($sChaine);
for($j = 0 ; $j <= $iLongueur-1 ; $j++)
{
	$sInverse .= $sChaine[$iLongueur-1-$j];
}
echo '<br /><br />'.$sChaine.' => '.$sInverse;
?>

	</body>
</html>