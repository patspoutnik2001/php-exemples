<!DOCTYPE html>
<html>
	<head>
		<title>Exercice 3 : bottle ding-ding</title>
		<meta charset="UTF-8" />
		<meta name="author" content="votre nom" />
	</head>
	<body>

<?php
/******************************************************************
 bottle ding ding
 remplacer les   multiples de 5 par bottle
 				 multiples de 7 par ding-ding
				 multiples de 5 et 7 par bottle ding-ding
******************************************************************/

for($i = 1 ; $i <= 99 ; $i++)
{
	if( ($i%5==0) AND ($i%7==0) ) 
	{
		echo 'bottle ding-ding<br />';
	}
	else if($i%5==0)
	{
		echo 'bottle<br />';
	}
	else if($i%7==0)
	{
		echo 'ding-ding<br />';
	}
	else
	{
		echo $i.'<br />';
	}
}



?>

	</body>
</html>