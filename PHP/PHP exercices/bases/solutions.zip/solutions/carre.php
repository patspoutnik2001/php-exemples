<!DOCTYPE html>
<html>
	<head>
		<title>Exercice 1 : carré</title>
		<meta charset="UTF-8" />
		<meta name="author" content="votre nom" />
	</head>
	<body>
	
<?php
/***************************************************************************
 Afficher le carré des nombres de 0 à 9
***************************************************************************/
for($i=0 ; $i <=9 ; $i++) // $i++ => $i=$i+1
{
	$iCarre = $i*$i ; // on a le carré de $i !
	echo 'Le carré de '.$i.' = '.$iCarre.'<br />'."\n";
	//echo "Le carré de $i = $iCarre <br />";
}
?>

	</body>
</html>