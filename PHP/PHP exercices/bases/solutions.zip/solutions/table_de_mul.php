<!DOCTYPE html>
<html>
	<head>
		<title>Exercice 2 : table mul</title>
		<meta charset="UTF-8" />
		<meta name="author" content="votre nom" />
	</head>
	<body>

<?php
/**********************************************************************************
// 	table multiplication de 10
	la première ligne et la première colonne contiennent les valeurs titres
	le reste le résultat du calcul ligne*colonne
	on traite donc la première ligne et la première colonne différemment du reste
	du tableau
**********************************************************************************/
$sMatable ='<table border="1">';
// première ligne
$sMatable .= '<tr><td>X</td>';
for($i=1 ; $i<=10 ; $i++)
{
	$sMatable .= '<td>'.$i.'</td>';
}
$sMatable .= '</tr>'."\n";
// fin première ligne
// début du reste
for($iLigne = 1 ; $iLigne <= 10 ; $iLigne++)
{
	// la première colonne contient le numéro de ligne
	$sMatable .= '<tr><td>'.$iLigne.'</td>';
	// le reste du tableau contient le produit ligne*colonne
	for($iColonne = 1 ; $iColonne <= 10 ; $iColonne++)
	{
		$sMatable .= '<td>'.($iLigne*$iColonne).'</td>';
	}
	$sMatable .= '</tr>'."\n";
}
$sMatable .= '</table>';

echo $sMatable;
?>
	</body>
</html>