<?php
$nbvisites = 0 ;
$fp = @fopen("compteur.txt","rb+");
if($fp!=false)
{
	$nbvisites = fgets($fp,11);
	$nbvisites++;
	fseek($fp,0);
	fputs($fp,$nbvisites);
	fclose($fp);
}

echo $nbvisites.' visiteurs';