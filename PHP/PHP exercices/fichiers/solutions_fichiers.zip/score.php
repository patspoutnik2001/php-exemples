<?php

$fichier = fopen("score.txt","rb");
if($fichier !== false)
{
	$scores = array();
	while (($data = fgetcsv($fichier, 1000, ";")) !== FALSE)  // on lit maximum 1000 caract�res par ligne, le d�limiter de champs est le point-virgule 
	{
		if(isset($scores[$data[0]]))
   		{
			$scores[$data[0]] += $data[1];
   		}
   	 	else
   	 	{
   	 		$scores[$data[0]] = $data[1];
   	 	}
   	 }
   	 fclose($fichier);
	echo '<pre>';
	print_r($scores);
	echo '</pre>';
}
else
{
	echo 'erreur fichier';
}